export function About() {
  return (
    <section id="about" className="py-24">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <p className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">About</p>
        <h2 className="text-4xl font-bold tracking-tight mb-6">A passionate marketer in the making</h2>
        <p className="text-lg text-muted-foreground leading-relaxed">
          I'm Sooryakrishnan, an aspiring digital marketer driven by curiosity and creativity.
          I help brands grow online through performance ads, engaging social content, and clean
          design. Always learning, always experimenting — building a foundation in modern marketing,
          one campaign at a time.
        </p>
      </div>
    </section>
  );
}
