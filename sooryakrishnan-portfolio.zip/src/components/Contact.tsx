import { Mail, Phone } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-24">
      <div className="max-w-4xl mx-auto px-6">
        <div
          className="rounded-3xl p-6 sm:p-10 md:p-16 text-center shadow-elegant"
          style={{ background: "var(--gradient-primary)" }}
        >
          <p className="text-sm font-semibold text-primary-foreground/80 uppercase tracking-wider mb-3">Contact</p>
          <h2 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">Let's work together</h2>
          <p className="text-primary-foreground/90 text-lg mb-10 max-w-xl mx-auto">
            Got a project in mind or just want to say hi? I'd love to hear from you.
          </p>
          <div className="grid sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
            <a
              href="tel:8590369755"
              className="group flex items-center gap-4 p-5 rounded-2xl bg-background/95 hover:bg-background transition-colors hover:scale-[1.02]"
            >
              <div className="h-12 w-12 rounded-xl bg-accent flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <Phone className="h-5 w-5" />
              </div>
              <div className="text-left">
                <p className="text-xs text-muted-foreground">Call me</p>
                <p className="font-semibold">+91 85903 69755</p>
              </div>
            </a>
            <a
              href="mailto:workwithsooryakrishnan@gmail.com"
              className="group flex items-center gap-4 p-5 rounded-2xl bg-background/95 hover:bg-background transition-colors hover:scale-[1.02]"
            >
              <div className="h-12 w-12 rounded-xl bg-accent flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <Mail className="h-5 w-5" />
              </div>
              <div className="text-left min-w-0 flex-1">
                <p className="text-xs text-muted-foreground">Email me</p>
                <p className="font-semibold text-sm sm:text-base break-all">workwithsooryakrishnan@gmail.com</p>
              </div>
            </a>
          </div>
        </div>
        <footer className="text-center text-sm text-muted-foreground mt-10">
          © {new Date().getFullYear()} Sooryakrishnan KS. Crafted with care.
        </footer>
      </div>
    </section>
  );
}
