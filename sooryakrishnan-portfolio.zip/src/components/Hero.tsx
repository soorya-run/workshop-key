import profile from "@/assets/profile.jpg";

export function Hero() {
  return (
    <section id="home" className="relative pt-32 pb-20 overflow-hidden">
      <div
        className="absolute inset-0 -z-10 opacity-60"
        style={{ background: "var(--gradient-soft)" }}
      />
      <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full blur-3xl opacity-30 -z-10"
        style={{ background: "var(--gradient-primary)" }} />

      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
        <div className="animate-fade-in">
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-medium mb-6">
            <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            Available for work
          </span>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-tight">
            Hi, I'm <span className="text-primary">Sooryakrishnan KS</span>
          </h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Aspiring Digital Marketer crafting growth-driven strategies with creativity, ads, and content.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="#contact"
              className="inline-flex items-center rounded-full px-6 py-3 text-sm font-semibold text-primary-foreground shadow-elegant hover:scale-105 transition-transform"
              style={{ background: "var(--gradient-primary)" }}
            >
              Hire Me
            </a>
            <a
              href="#contact"
              className="inline-flex items-center rounded-full px-6 py-3 text-sm font-semibold border border-border bg-background hover:bg-accent transition-colors"
            >
              Contact Me
            </a>
          </div>
        </div>
        <div className="relative flex justify-center md:justify-end animate-scale-in">
          <div className="absolute inset-0 rounded-full blur-2xl opacity-40"
            style={{ background: "var(--gradient-primary)" }} />
          <div className="relative h-72 w-72 md:h-96 md:w-96 rounded-full overflow-hidden border-4 border-background shadow-elegant">
            <img src={profile} alt="Sooryakrishnan KS" width={768} height={768}
              className="h-full w-full object-cover" />
          </div>
        </div>
      </div>
    </section>
  );
}
