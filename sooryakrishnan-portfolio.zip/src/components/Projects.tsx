import greencare from "@/assets/greencare.png.asset.json";
import oxford from "@/assets/oxfordsneakx.jpg.asset.json";

const projects = [
  {
    name: "GreenCare Property Management Pvt. Ltd",
    description: "Digital marketing & branding support for a property management company.",
    logo: greencare.url,
  },
  {
    name: "OxfordSneakx",
    description: "Social media & ad campaigns for a premium footwear brand.",
    logo: oxford.url,
  },
];

export function Projects() {
  return (
    <section id="projects" className="py-24">
      <div className="max-w-5xl mx-auto px-6">
        <div className="text-center mb-12">
          <p className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">Projects</p>
          <h2 className="text-4xl font-bold tracking-tight">My Work</h2>
        </div>
        <div className="grid gap-6 sm:grid-cols-2">
          {projects.map((p) => (
            <div
              key={p.name}
              className="group rounded-3xl border bg-card overflow-hidden hover:shadow-[var(--shadow-elegant)] transition-all"
            >
              <div className="aspect-[16/9] overflow-hidden bg-accent/30">
                <img
                  src={p.logo}
                  alt={`${p.name} logo`}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{p.name}</h3>
                <p className="text-muted-foreground text-sm">{p.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
