import { Megaphone, Search, Instagram, Palette, MapPin } from "lucide-react";

const services = [
  { icon: Megaphone, title: "Meta Ads", desc: "Targeted campaigns on Facebook & Instagram that convert." },
  { icon: Search, title: "Google Ads", desc: "Search & display ads to capture high-intent traffic." },
  
  { icon: Instagram, title: "Social Media Handling", desc: "End-to-end management of your social presence." },
  { icon: Palette, title: "Canva Designing", desc: "Eye-catching creatives for posts, ads, and stories." },
  { icon: MapPin, title: "Google My Business", desc: "Setup & optimization to dominate local search." },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-secondary/40">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-14">
          <p className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">Services</p>
          <h2 className="text-4xl font-bold tracking-tight">What I can do for you</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s) => (
            <div
              key={s.title}
              className="group p-7 rounded-2xl bg-card border border-border hover:border-primary/40 hover:shadow-elegant transition-all hover:-translate-y-1"
            >
              <div
                className="h-12 w-12 rounded-xl flex items-center justify-center mb-5 text-primary-foreground group-hover:scale-110 transition-transform"
                style={{ background: "var(--gradient-primary)" }}
              >
                <s.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
