const skills = [
  { name: "Meta Ads", level: 75 },
  { name: "Google Ads", level: 70 },
  { name: "Social Media Marketing", level: 85 },
  { name: "Canva Design", level: 90 },
  { name: "SEO Basics", level: 65 },
  { name: "Google My Business", level: 80 },
];

const tags = ["Content Strategy", "Copywriting", "Analytics", "Email Marketing", "Branding", "Reels Editing"];

export function Skills() {
  return (
    <section id="skills" className="py-24 bg-secondary/40">
      <div className="max-w-5xl mx-auto px-6">
        <div className="text-center mb-14">
          <p className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">Skills</p>
          <h2 className="text-4xl font-bold tracking-tight">Tools & Expertise</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-x-12 gap-y-6 mb-12">
          {skills.map((s) => (
            <div key={s.name}>
              <div className="flex justify-between mb-2 text-sm">
                <span className="font-medium">{s.name}</span>
                <span className="text-muted-foreground">{s.level}%</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{ width: `${s.level}%`, background: "var(--gradient-primary)" }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          {tags.map((t) => (
            <span
              key={t}
              className="px-4 py-2 rounded-full bg-card border border-border text-sm hover:border-primary hover:text-primary hover:scale-105 transition-all cursor-default"
            >
              {t}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
