import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Services } from "@/components/Services";
import { Projects } from "@/components/Projects";
import { Contact } from "@/components/Contact";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Sooryakrishnan KS — Aspiring Digital Marketer" },
      {
        name: "description",
        content:
          "Sooryakrishnan KS — Aspiring Digital Marketer offering Meta Ads, Google Ads, social media marketing, Canva design & GMB setup. Let's grow your brand.",
      },
      { property: "og:title", content: "Sooryakrishnan KS — Aspiring Digital Marketer" },
      { property: "og:description", content: "Meta Ads · Google Ads · Social Media · Canva · GMB. Let's grow your brand." },
      { property: "og:image", content: "/og-image.jpg" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Sooryakrishnan KS — Aspiring Digital Marketer" },
      { name: "twitter:description", content: "Meta Ads · Google Ads · Social Media · Canva · GMB." },
      { name: "twitter:image", content: "/og-image.jpg" },
    ],
  }),
});

function Index() {
  return (
    <main className="min-h-screen bg-background text-foreground scroll-smooth">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Projects />
      <Contact />
    </main>
  );
}
